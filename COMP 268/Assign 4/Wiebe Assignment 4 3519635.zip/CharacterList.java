/**
* title: CharacterList.java
* description: Create an rigid structure for all avalilable characters
* date: 03/10/2021
* Jackson Wiebe 3519635
* 1.0
*/

public enum CharacterList {
    ALICE,
    HATTER,
    QUEEN,
    CAT,
    CATERPILLAR,
    DORMOUSE
}