JAckson Wiebe
3519635
COMP 452 Assignment 3

#Video Demo
A video about my project can be found here: https://www.youtube.com/watch?v=y6tlDer1jmc

#Connect 4
An implimention of min/ max algotrythem with alpha-beta prunning.

#Snake
This is an implimention of the classic snake game that uses a Q-learning approach. The AI State has 8 pieces of information (Danger in 4 cardinal directions, Food in 4 cardinal directions). This information is feed into a Q-learning algo that attempts to learn the best moves for each state. The AI is able to reach a high score of roughly 40 after 500 play cycles.

#Instructions to compile/ run:
A compiled binary jar has been provided for each program
The files can also be compiled with VScode with the Java plugin. Simply by opening the project files in VScode, pressing F1 and typing "Java: Export Jar"

From a command prompt or Terminal
- Ensure the machine has Java 8 or newer. Use the command "java -version"
- Navigate to the game files directory
- Run the command "java -jar connect4.jar"




